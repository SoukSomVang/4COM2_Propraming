﻿namespace _4COM2_Propraming
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            menuStrip1 = new MenuStrip();
            ຕງຄາToolStripMenuItem = new ToolStripMenuItem();
            ເພມຜໃຊໃໝToolStripMenuItem = new ToolStripMenuItem();
            ຕງຄາການເຊອມຕToolStripMenuItem = new ToolStripMenuItem();
            ສຳຮອວຂມນToolStripMenuItem = new ToolStripMenuItem();
            ຈດການຂມນພນToolStripMenuItem = new ToolStripMenuItem();
            ຂມນToolStripMenuItem = new ToolStripMenuItem();
            ຂມນຜສະໜອງToolStripMenuItem = new ToolStripMenuItem();
            ຂມນປະເພດສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ຂມນສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ຈດຊສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ສງຊສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ນຳສນຄາເຂາຮານToolStripMenuItem = new ToolStripMenuItem();
            ຂາຍສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ກວດສອບສນຄາToolStripMenuItem = new ToolStripMenuItem();
            ຂາຍສນຄາToolStripMenuItem1 = new ToolStripMenuItem();
            ລາຍງານToolStripMenuItem = new ToolStripMenuItem();
            ລາຍງານສນຄາໃນຮານToolStripMenuItem = new ToolStripMenuItem();
            ລາຍງານຂມນຜສະໜອງToolStripMenuItem = new ToolStripMenuItem();
            ລາຍວToolStripMenuItem = new ToolStripMenuItem();
            ລາຍງານລາຍຮບToolStripMenuItem = new ToolStripMenuItem();
            ລາຍງານລາຍຈາຍToolStripMenuItem = new ToolStripMenuItem();
            ອອກຈາກລະບບToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Saysettha OT", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            menuStrip1.ImageScalingSize = new Size(40, 40);
            menuStrip1.Items.AddRange(new ToolStripItem[] { ຕງຄາToolStripMenuItem, ຈດການຂມນພນToolStripMenuItem, ຈດຊສນຄາToolStripMenuItem, ຂາຍສນຄາToolStripMenuItem, ລາຍງານToolStripMenuItem, ອອກຈາກລະບບToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1537, 48);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // ຕງຄາToolStripMenuItem
            // 
            ຕງຄາToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ເພມຜໃຊໃໝToolStripMenuItem, ຕງຄາການເຊອມຕToolStripMenuItem, ສຳຮອວຂມນToolStripMenuItem });
            ຕງຄາToolStripMenuItem.Image = (Image)resources.GetObject("ຕງຄາToolStripMenuItem.Image");
            ຕງຄາToolStripMenuItem.Name = "ຕງຄາToolStripMenuItem";
            ຕງຄາToolStripMenuItem.Size = new Size(168, 44);
            ຕງຄາToolStripMenuItem.Text = "ຕັ້ງຄ່າລະບົບ";
            // 
            // ເພມຜໃຊໃໝToolStripMenuItem
            // 
            ເພມຜໃຊໃໝToolStripMenuItem.Name = "ເພມຜໃຊໃໝToolStripMenuItem";
            ເພມຜໃຊໃໝToolStripMenuItem.Size = new Size(244, 36);
            ເພມຜໃຊໃໝToolStripMenuItem.Text = "ເພີ່ມຜູ້ໃຊ້ໃໝ່";
            // 
            // ຕງຄາການເຊອມຕToolStripMenuItem
            // 
            ຕງຄາການເຊອມຕToolStripMenuItem.Name = "ຕງຄາການເຊອມຕToolStripMenuItem";
            ຕງຄາການເຊອມຕToolStripMenuItem.Size = new Size(244, 36);
            ຕງຄາການເຊອມຕToolStripMenuItem.Text = "ຕັ້ງຄ່າການເຊືອມຕໍ່";
            // 
            // ສຳຮອວຂມນToolStripMenuItem
            // 
            ສຳຮອວຂມນToolStripMenuItem.Name = "ສຳຮອວຂມນToolStripMenuItem";
            ສຳຮອວຂມນToolStripMenuItem.Size = new Size(244, 36);
            ສຳຮອວຂມນToolStripMenuItem.Text = "ສຳຮອງຂໍ້ມູນ";
            // 
            // ຈດການຂມນພນToolStripMenuItem
            // 
            ຈດການຂມນພນToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ຂມນToolStripMenuItem, ຂມນຜສະໜອງToolStripMenuItem, ຂມນປະເພດສນຄາToolStripMenuItem, ຂມນສນຄາToolStripMenuItem });
            ຈດການຂມນພນToolStripMenuItem.Image = (Image)resources.GetObject("ຈດການຂມນພນToolStripMenuItem.Image");
            ຈດການຂມນພນToolStripMenuItem.Name = "ຈດການຂມນພນToolStripMenuItem";
            ຈດການຂມນພນToolStripMenuItem.Size = new Size(232, 44);
            ຈດການຂມນພນToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນພື້ນຖານ";
            // 
            // ຂມນToolStripMenuItem
            // 
            ຂມນToolStripMenuItem.Name = "ຂມນToolStripMenuItem";
            ຂມນToolStripMenuItem.Size = new Size(251, 36);
            ຂມນToolStripMenuItem.Text = "ຂໍ້ມູນຜູ້ສະໜອງ";
            ຂມນToolStripMenuItem.Click += ຂມນToolStripMenuItem_Click;
            // 
            // ຂມນຜສະໜອງToolStripMenuItem
            // 
            ຂມນຜສະໜອງToolStripMenuItem.Name = "ຂມນຜສະໜອງToolStripMenuItem";
            ຂມນຜສະໜອງToolStripMenuItem.Size = new Size(251, 36);
            ຂມນຜສະໜອງToolStripMenuItem.Text = "ຂໍ້ມູນຜູ້ລູກຄ້າ";
            // 
            // ຂມນປະເພດສນຄາToolStripMenuItem
            // 
            ຂມນປະເພດສນຄາToolStripMenuItem.Name = "ຂມນປະເພດສນຄາToolStripMenuItem";
            ຂມນປະເພດສນຄາToolStripMenuItem.Size = new Size(251, 36);
            ຂມນປະເພດສນຄາToolStripMenuItem.Text = "ຂໍ້ມູນປະເພດສິນຄ້າ";
            // 
            // ຂມນສນຄາToolStripMenuItem
            // 
            ຂມນສນຄາToolStripMenuItem.Name = "ຂມນສນຄາToolStripMenuItem";
            ຂມນສນຄາToolStripMenuItem.Size = new Size(251, 36);
            ຂມນສນຄາToolStripMenuItem.Text = "ຂໍ້ມູນສິນຄ້າ";
            // 
            // ຈດຊສນຄາToolStripMenuItem
            // 
            ຈດຊສນຄາToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ສງຊສນຄາToolStripMenuItem, ນຳສນຄາເຂາຮານToolStripMenuItem });
            ຈດຊສນຄາToolStripMenuItem.Image = (Image)resources.GetObject("ຈດຊສນຄາToolStripMenuItem.Image");
            ຈດຊສນຄາToolStripMenuItem.Name = "ຈດຊສນຄາToolStripMenuItem";
            ຈດຊສນຄາToolStripMenuItem.Size = new Size(155, 44);
            ຈດຊສນຄາToolStripMenuItem.Text = "ຈັດຊື້ສິນຄ້າ";
            // 
            // ສງຊສນຄາToolStripMenuItem
            // 
            ສງຊສນຄາToolStripMenuItem.Name = "ສງຊສນຄາToolStripMenuItem";
            ສງຊສນຄາToolStripMenuItem.Size = new Size(239, 36);
            ສງຊສນຄາToolStripMenuItem.Text = "ສັ່ງຊື້ສິນຄ້າ";
            // 
            // ນຳສນຄາເຂາຮານToolStripMenuItem
            // 
            ນຳສນຄາເຂາຮານToolStripMenuItem.Name = "ນຳສນຄາເຂາຮານToolStripMenuItem";
            ນຳສນຄາເຂາຮານToolStripMenuItem.Size = new Size(239, 36);
            ນຳສນຄາເຂາຮານToolStripMenuItem.Text = "ນຳສິນຄ້າເຂົ້າຮ້ານ";
            // 
            // ຂາຍສນຄາToolStripMenuItem
            // 
            ຂາຍສນຄາToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ກວດສອບສນຄາToolStripMenuItem, ຂາຍສນຄາToolStripMenuItem1 });
            ຂາຍສນຄາToolStripMenuItem.Image = (Image)resources.GetObject("ຂາຍສນຄາToolStripMenuItem.Image");
            ຂາຍສນຄາToolStripMenuItem.Name = "ຂາຍສນຄາToolStripMenuItem";
            ຂາຍສນຄາToolStripMenuItem.Size = new Size(154, 44);
            ຂາຍສນຄາToolStripMenuItem.Text = "ຂາຍສິນຄ້າ";
            // 
            // ກວດສອບສນຄາToolStripMenuItem
            // 
            ກວດສອບສນຄາToolStripMenuItem.Name = "ກວດສອບສນຄາToolStripMenuItem";
            ກວດສອບສນຄາToolStripMenuItem.Size = new Size(229, 36);
            ກວດສອບສນຄາToolStripMenuItem.Text = "ກວດສອບສິນຄ້າ";
            // 
            // ຂາຍສນຄາToolStripMenuItem1
            // 
            ຂາຍສນຄາToolStripMenuItem1.Name = "ຂາຍສນຄາToolStripMenuItem1";
            ຂາຍສນຄາToolStripMenuItem1.Size = new Size(229, 36);
            ຂາຍສນຄາToolStripMenuItem1.Text = "ຂາຍສິນຄ້າ";
            // 
            // ລາຍງານToolStripMenuItem
            // 
            ລາຍງານToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ລາຍງານສນຄາໃນຮານToolStripMenuItem, ລາຍງານຂມນຜສະໜອງToolStripMenuItem, ລາຍວToolStripMenuItem, ລາຍງານລາຍຮບToolStripMenuItem, ລາຍງານລາຍຈາຍToolStripMenuItem });
            ລາຍງານToolStripMenuItem.Image = (Image)resources.GetObject("ລາຍງານToolStripMenuItem.Image");
            ລາຍງານToolStripMenuItem.Name = "ລາຍງານToolStripMenuItem";
            ລາຍງານToolStripMenuItem.Size = new Size(139, 44);
            ລາຍງານToolStripMenuItem.Text = "ລາຍງານ";
            // 
            // ລາຍງານສນຄາໃນຮານToolStripMenuItem
            // 
            ລາຍງານສນຄາໃນຮານToolStripMenuItem.Name = "ລາຍງານສນຄາໃນຮານToolStripMenuItem";
            ລາຍງານສນຄາໃນຮານToolStripMenuItem.Size = new Size(295, 36);
            ລາຍງານສນຄາໃນຮານToolStripMenuItem.Text = "ລາຍງານສິ້ນຄ້າໃນຮ້ານ";
            // 
            // ລາຍງານຂມນຜສະໜອງToolStripMenuItem
            // 
            ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Name = "ລາຍງານຂມນຜສະໜອງToolStripMenuItem";
            ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Size = new Size(295, 36);
            ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນຜູ້ສະໜອງ";
            // 
            // ລາຍວToolStripMenuItem
            // 
            ລາຍວToolStripMenuItem.Name = "ລາຍວToolStripMenuItem";
            ລາຍວToolStripMenuItem.Size = new Size(295, 36);
            ລາຍວToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນລູກຄ້າ";
            // 
            // ລາຍງານລາຍຮບToolStripMenuItem
            // 
            ລາຍງານລາຍຮບToolStripMenuItem.Name = "ລາຍງານລາຍຮບToolStripMenuItem";
            ລາຍງານລາຍຮບToolStripMenuItem.Size = new Size(295, 36);
            ລາຍງານລາຍຮບToolStripMenuItem.Text = "ລາຍງານລາຍຮັບ";
            // 
            // ລາຍງານລາຍຈາຍToolStripMenuItem
            // 
            ລາຍງານລາຍຈາຍToolStripMenuItem.Name = "ລາຍງານລາຍຈາຍToolStripMenuItem";
            ລາຍງານລາຍຈາຍToolStripMenuItem.Size = new Size(295, 36);
            ລາຍງານລາຍຈາຍToolStripMenuItem.Text = "ລາຍງານລາຍຈ່າຍ";
            // 
            // ອອກຈາກລະບບToolStripMenuItem
            // 
            ອອກຈາກລະບບToolStripMenuItem.Image = (Image)resources.GetObject("ອອກຈາກລະບບToolStripMenuItem.Image");
            ອອກຈາກລະບບToolStripMenuItem.Name = "ອອກຈາກລະບບToolStripMenuItem";
            ອອກຈາກລະບບToolStripMenuItem.Size = new Size(195, 44);
            ອອກຈາກລະບບToolStripMenuItem.Text = "ອອກຈາກລະບົບ";
            ອອກຈາກລະບບToolStripMenuItem.Click += ອອກຈາກລະບບToolStripMenuItem_Click;
            // 
            // frmMainMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1537, 840);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmMainMenu";
            Text = "frmMainMenu";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem ຕງຄາToolStripMenuItem;
        private ToolStripMenuItem ເພມຜໃຊໃໝToolStripMenuItem;
        private ToolStripMenuItem ຕງຄາການເຊອມຕToolStripMenuItem;
        private ToolStripMenuItem ສຳຮອວຂມນToolStripMenuItem;
        private ToolStripMenuItem ຈດການຂມນພນToolStripMenuItem;
        private ToolStripMenuItem ຈດຊສນຄາToolStripMenuItem;
        private ToolStripMenuItem ຂາຍສນຄາToolStripMenuItem;
        private ToolStripMenuItem ຂມນToolStripMenuItem;
        private ToolStripMenuItem ຂມນຜສະໜອງToolStripMenuItem;
        private ToolStripMenuItem ຂມນປະເພດສນຄາToolStripMenuItem;
        private ToolStripMenuItem ຂມນສນຄາToolStripMenuItem;
        private ToolStripMenuItem ສງຊສນຄາToolStripMenuItem;
        private ToolStripMenuItem ນຳສນຄາເຂາຮານToolStripMenuItem;
        private ToolStripMenuItem ກວດສອບສນຄາToolStripMenuItem;
        private ToolStripMenuItem ຂາຍສນຄາToolStripMenuItem1;
        private ToolStripMenuItem ລາຍງານToolStripMenuItem;
        private ToolStripMenuItem ລາຍງານສນຄາໃນຮານToolStripMenuItem;
        private ToolStripMenuItem ລາຍງານຂມນຜສະໜອງToolStripMenuItem;
        private ToolStripMenuItem ລາຍວToolStripMenuItem;
        private ToolStripMenuItem ລາຍງານລາຍຮບToolStripMenuItem;
        private ToolStripMenuItem ລາຍງານລາຍຈາຍToolStripMenuItem;
        private ToolStripMenuItem ອອກຈາກລະບບToolStripMenuItem;
    }
}
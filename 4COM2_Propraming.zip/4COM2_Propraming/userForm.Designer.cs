﻿namespace _4COM2_Propraming
{
    partial class suplyerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            textBox4 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            textBox5 = new TextBox();
            label6 = new Label();
            textBox6 = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Font = new Font("Saysettha OT", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(-6, -5);
            button1.Name = "button1";
            button1.Size = new Size(1100, 75);
            button1.TabIndex = 0;
            button1.Text = "ຟອມຂໍ້ມູນຜູ້ສະໜອງ";
            button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Saysettha OT", 12F);
            label1.Location = new Point(21, 93);
            label1.Name = "label1";
            label1.Size = new Size(162, 32);
            label1.TabIndex = 1;
            label1.Text = "ຮັບຂໍ້ມູນຜູ້ສະໜອງ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Saysettha OT", 12F);
            textBox1.Location = new Point(212, 154);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(852, 42);
            textBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Saysettha OT", 12F);
            label2.Location = new Point(54, 157);
            label2.Name = "label2";
            label2.Size = new Size(156, 32);
            label2.TabIndex = 3;
            label2.Text = "ລະຫັດຜູ້ສະໜອງ:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Saysettha OT", 12F);
            label3.Location = new Point(54, 208);
            label3.Name = "label3";
            label3.Size = new Size(86, 32);
            label3.TabIndex = 4;
            label3.Text = "ຊື່ບໍລິສັດ:";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Saysettha OT", 12F);
            textBox2.Location = new Point(212, 205);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(852, 42);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Saysettha OT", 12F);
            textBox3.Location = new Point(212, 306);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(852, 42);
            textBox3.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Saysettha OT", 12F);
            label4.Location = new Point(54, 309);
            label4.Name = "label4";
            label4.Size = new Size(48, 32);
            label4.TabIndex = 8;
            label4.Text = "ທີ່ຢູ່:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Saysettha OT", 12F);
            label5.Location = new Point(54, 258);
            label5.Name = "label5";
            label5.Size = new Size(88, 32);
            label5.TabIndex = 7;
            label5.Text = "ຊື່ຜູ້ຕິດຕໍ່:";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Saysettha OT", 12F);
            textBox4.Location = new Point(212, 255);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(852, 42);
            textBox4.TabIndex = 6;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.Font = new Font("Saysettha OT", 12F);
            button2.Location = new Point(212, 429);
            button2.Name = "button2";
            button2.Size = new Size(126, 51);
            button2.TabIndex = 10;
            button2.Text = "ເພີ່ມຂໍ້ມູນ";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.PeachPuff;
            button3.Font = new Font("Saysettha OT", 12F);
            button3.Location = new Point(402, 429);
            button3.Name = "button3";
            button3.Size = new Size(112, 51);
            button3.TabIndex = 11;
            button3.Text = "ແກ້ໄຂຂໍ້ມູນ";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Plum;
            button4.Font = new Font("Saysettha OT", 12F);
            button4.Location = new Point(588, 429);
            button4.Name = "button4";
            button4.Size = new Size(106, 51);
            button4.TabIndex = 12;
            button4.Text = "ລົບຂໍ້ມູນ";
            button4.UseVisualStyleBackColor = false;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Saysettha OT", 12F);
            textBox5.Location = new Point(212, 361);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(332, 42);
            textBox5.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Saysettha OT", 12F);
            label6.Location = new Point(53, 364);
            label6.Name = "label6";
            label6.Size = new Size(105, 32);
            label6.TabIndex = 13;
            label6.Text = "ເບິໂທຕິດຕໍ່:";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Saysettha OT", 12F);
            textBox6.Location = new Point(732, 364);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(332, 42);
            textBox6.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Saysettha OT", 12F);
            label7.Location = new Point(573, 367);
            label7.Name = "label7";
            label7.Size = new Size(66, 32);
            label7.TabIndex = 15;
            label7.Text = "ອີເມລ:";
            // 
            // suplyerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1086, 537);
            ControlBox = false;
            Controls.Add(textBox6);
            Controls.Add(label7);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(textBox2);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "suplyerForm";
            Text = "userForm";
            Load += userForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Label label3;
        private TextBox textBox2;
        private TextBox textBox3;
        private Label label4;
        private Label label5;
        private TextBox textBox4;
        private Button button2;
        private Button button3;
        private Button button4;
        private TextBox textBox5;
        private Label label6;
        private TextBox textBox6;
        private Label label7;
    }
}